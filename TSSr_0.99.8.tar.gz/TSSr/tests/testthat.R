# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.

library(testthat)
library(TSSr)

test_check("TSSr")
